<?php

return [
    // description
    'description' => '',

    // キーワード
    'keywords' => '',

    // タイトル
    'title' => 'Laravel リファレンス / サンプルアプリケーション',
];
