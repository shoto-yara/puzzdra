<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

/**
 * Class Controller
 */
abstract class Controller extends BaseController
{
    /**
     * このサンプルアプリケーションでは、デフォルトで記述されているトレイトの機能は
     * コントローラクラスで利用しないため、削除しています。
     */
}
