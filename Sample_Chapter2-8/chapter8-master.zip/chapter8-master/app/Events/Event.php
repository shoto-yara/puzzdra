<?php

namespace App\Events;

/**
 * Class Event
 */
abstract class Event
{
    //
}
