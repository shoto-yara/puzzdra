<?php

return [
    'register' => [
        'success' => 'Created a successful account'
    ],
];
