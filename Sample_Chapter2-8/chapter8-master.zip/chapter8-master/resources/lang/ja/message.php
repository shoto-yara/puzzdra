<?php

/**
 * 言語ファイル追加例
 */
return [
    'register' => [
        'success' => 'ユーザーが作成されました。'
    ],
];
