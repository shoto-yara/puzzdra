<footer class="footer">
    <div class="container">
        <p class="text-muted">Laravel リファレンス / サンプルアプリケーション</p>
    </div>
</footer>
