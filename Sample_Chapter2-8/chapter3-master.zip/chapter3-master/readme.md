## Laravelリファレンス chapter3 sample

このリポジトリはImpress社から発行されている「Laravelリファレンス」の「chapter03 データベース」で言及しているサンプルデータベースです。

* `app/` 以下のモデルファイル
* `database/migrations/` 以下のマイグレーションファイル
* `database/seeds/` 以下のシーダーファイル
* `database/factories/` 以下の`Faker`を使ったモデルファクトリの例

など、実際に手を動かしながら試してみてください。
