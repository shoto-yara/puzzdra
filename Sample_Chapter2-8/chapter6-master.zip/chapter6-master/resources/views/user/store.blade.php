<h1>Complete</h1>
<a href="{{ route('user.index') }}">user list</a>
