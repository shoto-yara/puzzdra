{{ $variable }}
