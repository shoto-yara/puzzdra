<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Entry.
 */
class Entry extends Model
{
    //
}
