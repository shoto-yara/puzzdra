<?php

namespace App\Repositories;

/**
 * Interface UserRepositoryInterface.
 */
interface UserRepositoryInterface
{
    /**
     * @return array
     */
    public function all();
}
